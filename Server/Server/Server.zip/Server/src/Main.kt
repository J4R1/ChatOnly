//main STARTS THE SERVER
fun main(args: Array<String>) {
    ChatServer().serve()
}
