interface ChatHistoryObserver {
    fun newMessage(message: ChatMessage){
    }
}